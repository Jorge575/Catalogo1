import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Pagina2Page } from './pagina2';

@NgModule({
  declarations: [
    Pagina2Page,
  ],
  imports: [
    IonicPageModule.forChild(Pagina2Page),
  ],
})
export class Pagina2PageModule {}
